
This file provides basic information on the replication archive for the paper "Getting Rich Too Fast? Experimental Evidence on Voters' Reactions to Politicians' Wealth Accumulation in India," by Simon Chauchard, Marko Klasnja, and S.P. Harish. 

Contents of the directory: 

*** MAIN DATASETS ***

conjoint-survey.dta -- Main survey dataset, including the conjoint experiment data
second-survey.dta -- Second "information" survey dataset

*** REPLICATION CODE ***

paper.do -- replicates all the figures in the article
appendix.do -- replicates all the tables and figures in the appendix

*** AUXILIARY DATASETS ***

asset-increase-data.xlsx (SOURCE: Association for Democratic Reforms, myneta.info)
asset-increase-winning-data.dta (SOURCE: Association for Democratic Reforms, myneta.info; "Indian State Assembly Election and Candidates Data (1962-Present)," Trivedi Centre for Political Data, Ashoka University)
awn-dates-titles.csv (SOURCE: Access World News)
census-2011-data.csv (SOURCE: Census of India, 2011)
eci-electoral-data.csv (SOURCE: Electoral Commission of India)
google-ngrams-data.xlsx (SOURCE: Google Ngrams)
idhs-data.dta (SOURCE: India Demogrpahic and Health Survey, Wave II)

Notes: 

- The replication code was built in Stata/SE v15.1 for Windows (64-bit x86-64), revision 08 Mar 2018. 
- The replication code requires two user-written commands: -matmap-, and -frmttable-. Type findit (commandname) to find and install these packages if needed. 



For any questions or concerns, please email to marko.klasnja@georgetown.edu



