

*	************************************************************************
* 	File-Name: 	ReadMe.txt
*	Log-file:	na
*	Date:  		04/27/2017
*	Author: 	MA, PB, HSP, JU
*	Purpose:   	ReadMe file for the Science Advances paper
*	************************************************************************

*	************************************************************************
*	Summary
*	************************************************************************

ReadMe.txt file for "Does basic energy access generate socioeconomic benefits? A field experiment with off-grid solar power in India" (M. Aklin, P. Bayer, S. P. Harish, J. Urpelainen, Science Advances 3, e1602153 (2017).

This file explains how to replicate the analysis in the article and the supplementary appendix. 

*	************************************************************************
*	Package content
*	************************************************************************

The replication package contains the following files:

(1) ReadMe.txt. This file.
(2) ReplicationDataRaw.dta: the raw (pre-processed) dataset.
(3) ReplicationImpactEvaluationCoding.do: a Stata do file to process and code the dataset. 
(4) ReplicationDataFinal.dta: the processed dataset. This file can be re-created by running ReplicationImpactEvaluationCoding.do. 
(5) ReplicationImpactEvaluationAnalysis.do: a Stata do file to replicate the tables and figures in the article. 
(6) ReplicationExternalValidity.do: a Stata do file to compute the results regarding the external validity of our findings reported in the Supplementary Material.
(7) ReplicationPlacebo.do: a State do file to compute the placebo tests reported in the Supplementary material.
(8) ReplicationCensusIndiaData.dta: extract of data from the Indian census. To be used with ReplicationExternalValidity.do.
(9) ReplicationCensusUPData: extract of data from the Uttar Pradesh census. To be used with ReplicationExternalValidity.do.


*	************************************************************************
*	Instructions for the main results
*	************************************************************************

(1) Save all the files in the same folder.
(2) Run ReplicationImpactEvaluationAnalysis.do. This file will automatically run the coding (data processing) file first, then complete all other tasks to replicate all tables and figures (except for those related to the placebo tests and external validity).

Note: 
:: All figures and tables will be saved in the same folder as this replication package.
:: To create the tables in LaTeX, you will need to install >estout< in Stata.
:: ReplicationExternalValidity.do and ReplicationPlacebo.do need to be run separately. 
