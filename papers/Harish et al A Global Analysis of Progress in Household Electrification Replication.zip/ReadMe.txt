
*	************************************************************************
* 	File-Name: 	ReadMe.txt
*	Date:  		07/20/2018
*	Author: 	Michaël Aklin, S.P. Harish, Johannes Urpelainen
*	Purpose:   	ReadMe file to replicate the results of Aklin, Michaël, S.P. 
*			Harish, and Johannes Urpelainen. "A Global Analysis of Progress 
*			in Household Electrification," Energy Policy.
*	************************************************************************


*	************************************************************************
*	Summary
*	************************************************************************

This file explains how to replicate the results of:

Aklin, Michaël, S.P. Harish, and Johannes Urpelainen. "A Global Analysis of Progress in Household Electrification," Energy Policy.

The replication package contains the following files:

:: ReadMe.txt: this file.
:: Aklin et al. Replication Code.do: a Stata do file that replicates the results (Tables and Figures) from the manuscript. 
:: ReplicationData.dta: a Stata dataset that is needed to replicate the results. 
:: Aklin et al. SI.pdf: the supplementary material that is referred to in the manuscript. 


*	************************************************************************
*	Instructions
*	************************************************************************

To replicate our results:
(1) Open "Aklin et al. Replication Code.do" in Stata.
(2) Modify the code where needed. The only modifications pertain to (a) updating the working directory, and (b) the code needed to construct the maps.

Note: the maps require additional downloads from other sources. Please see the do file to locate the links to the relevant files. 



