
Paper title: Economics of Household Technology Adoption in Developing Countries: Evidence from Solar Technology Adoption in Rural India
Authors: Michael Aklin (Pittsburgh), Patrick Bayer (Glasgow), S.P. Harish (College of William & Mary), and Johannes Urpelainen (SAIS Johns Hopkins)
Corresponding author: Patrick Bayer, University of Glasgow, email: patrick.bayer@glasgow.ac.uk
Journal: Energy Economics
Permanent URL: https://doi.org/10.1016/j.eneco.2018.02.011
This version: 5 March 2018

All files/ data were created/ analysed in Stata/SE 14.2 on Windows 10, 64 bit
Machine: Intel(R) Core(TM) i7-4650U CPU @ 1.70Ghz 2.30Ghz with 8GB RAM

# ============================================================================================
# TABLE OF CONTENTS (file by file)
# ============================================================================================

Data sets:
- adoption_data.dta (main data set, Stata format)
- summary_survey.dta (auxilliary data set, Stata format)

Code files:
- main.do (analysis file for main text)
- appendix.do (analysis file for appendix information)
- prep.do (coding file, run automatically from both other do files)

Notes:
- Please place all files in the same folder.
- 'prep.do' is the coding file, which creates variables and labels; it is called from both other files, so there is no need to run it separately. The file is made available be transparent about how variables are created.
- The 'main.do' file replicates the results and claims as they are presented in the main text.
- The 'appendix.do' file replicates the results presented in the supplementary online materials.
- Note that the main text of the published paper reports results from logistic regression models in odds-ratios instead of the raw coefficients. To translate non-exponentiated raw coefficients into odds-ratios, the 'esttab' command needs to be run with the 'eform' option to obtain the exact same coefficients.

# ============================================================================================